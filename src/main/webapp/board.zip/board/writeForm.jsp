<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script>
		function checkForm() {
		    const f = document.writeForm;   
		    if (f.title.value.trim() === '') {
		        
		        alert('제목을 입력하세요.');
		        f.title.focus();   
		        return false;      
		    }
		    if (f.writer.value.trim() === '') {
		        alert('작성자를 입력하세요.');
		        f.writer.focus();
		        return false;
		    }
		    if (f.content.value.trim() === '') {
		        alert('내용을 입력하세요.');
		        f.content.focus();
		        return false;
		    }
		    return true;           
		}
</script>
</head>
<body>
      
  <div align="center">
     <hr>
     <h2>게시판 등록폼</h2>
     <hr>
     
     <form  name="writeForm" action="write.jsp" method="post" onsubmit="return checkForm()">
         <table border="1" style="width:80%;">
		      <tr>
		          <th width="25%">제목</th>
		          <td><input type="text" name="title" size="100"></td>
		      </tr>
		      <tr>
		          <th width="25%">작성자</th>
		          <td><input type="text" name="writer" size="100"></td>
		      </tr>
		      <tr>
		          <th width="25%">내용</th>
		          <td>
		          	<textarea rows="10" cols="100" name="content"></textarea>
		          </td>
		      </tr>
             
         </table>
         <br>
         <!--<input type="submit" value = "등록">  -->
         <button type="submit">등  록</button>
     </form>
  </div>

</body>
</html>